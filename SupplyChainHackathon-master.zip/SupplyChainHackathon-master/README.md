# SupplyChainHackathon
Project files for Supply Chain Hackathon problem 2

There should be 2 applications:
1.  Client application for truckers
2.  Server application for port

Requireed functionalities for client application:
    -Book/update/delete pickup for specific cargoes at specific time
    -Pickup must be posted to the server application's calendar

Required functionalities for server application:
    -Post pickup slots for available cargoes
    -Accept/reject
    -Delete pickup request from trucker
    -Algo to optimize reduce congestion

